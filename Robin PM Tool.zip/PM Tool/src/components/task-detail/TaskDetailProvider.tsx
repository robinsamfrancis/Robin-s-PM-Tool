import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { TaskDetailDialog } from "./TaskDetailDialog";
import { useWorkspaceStore } from "@/lib/workspace-store";

interface Ctx {
  openTask: (id: string) => void;
  closeTask: () => void;
  openId: string | null;
}

const TaskDetailContext = createContext<Ctx | null>(null);

export function TaskDetailProvider({ children }: { children: ReactNode }) {
  const [openId, setOpenId] = useState<string | null>(null);
  const { seedItemDetails } = useWorkspaceStore();

  const openTask = useCallback(
    (id: string) => {
      seedItemDetails(id);
      setOpenId(id);
    },
    [seedItemDetails],
  );
  const closeTask = useCallback(() => setOpenId(null), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && openId) setOpenId(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openId]);

  return (
    <TaskDetailContext.Provider value={{ openTask, closeTask, openId }}>
      {children}
      <TaskDetailDialog openId={openId} onClose={closeTask} onOpenOther={openTask} />
    </TaskDetailContext.Provider>
  );
}

export function useTaskDetail() {
  const ctx = useContext(TaskDetailContext);
  if (!ctx) throw new Error("useTaskDetail must be inside TaskDetailProvider");
  return ctx;
}
