import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Activity as ActivityIcon,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Calendar,
  Check,
  CheckSquare,
  ChevronRight,
  Clock,
  FileText,
  GitBranch,
  GitPullRequest,
  Image as ImageIcon,
  Link as LinkIcon,
  ListChecks,
  ListTree,
  MessageSquare,
  MoreHorizontal,
  Paperclip,
  Play,
  Plus,
  RotateCcw,
  Share2,
  Smile,
  Target,
  Trash2,
  TrendingUp,
  Upload,
  X,
} from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { PersonAvatar } from "@/components/PersonAvatar";
import { cn } from "@/lib/utils";
import {
  DIRECTORY,
  ISSUE_TYPE_META,
  LINK_TYPE_META,
  PRIORITY_META,
  useWorkspaceStore,
  type BacklogItem,
  type LinkType,
  type Priority,
} from "@/lib/workspace-store";


const TABS = [
  { id: "overview", label: "Overview", icon: Target },
  { id: "description", label: "Description", icon: FileText },
  { id: "acceptance", label: "Acceptance", icon: CheckSquare },
  { id: "subtasks", label: "Subtasks", icon: ListTree },
  { id: "dependencies", label: "Dependencies", icon: LinkIcon },
  { id: "comments", label: "Comments", icon: MessageSquare },
  { id: "activity", label: "Activity", icon: ActivityIcon },
  { id: "attachments", label: "Attachments", icon: Paperclip },
  { id: "time", label: "Time tracking", icon: Clock },
  { id: "development", label: "Development", icon: GitBranch },
  { id: "testing", label: "Testing", icon: ListChecks },
] as const;

type TabId = (typeof TABS)[number]["id"];

const CURRENT_USER_ID = "u1"; // mock signed-in user

interface Props {
  openId: string | null;
  onClose: () => void;
  onOpenOther: (id: string) => void;
}

export function TaskDetailDialog({ openId, onClose, onOpenOther }: Props) {
  const { store } = useWorkspaceStore();
  const item = openId ? store.items.find((i) => i.id === openId) : null;
  const [tab, setTab] = useState<TabId>("overview");

  useEffect(() => {
    if (openId) setTab("overview");
  }, [openId]);

  return (
    <Dialog open={!!openId} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-[1280px] w-[96vw] h-[92vh] p-0 overflow-hidden gap-0 flex flex-col">
        <DialogTitle className="sr-only">{item?.title ?? "Task details"}</DialogTitle>
        {item ? (
          <TaskBody item={item} tab={tab} setTab={setTab} onOpenOther={onOpenOther} onClose={onClose} />
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
            Loading…
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function TaskBody({
  item,
  tab,
  setTab,
  onOpenOther,
  onClose,
}: {
  item: BacklogItem;
  tab: TabId;
  setTab: (t: TabId) => void;
  onOpenOther: (id: string) => void;
  onClose: () => void;
}) {
  const { store, updateItem } = useWorkspaceStore();
  const workspace = store.workspaces.find((w) => w.code === item.workspaceCode);
  const meta = ISSUE_TYPE_META[item.type];
  const sprint = store.sprints.find((s) => s.id === item.sprintId);

  const statuses = workspace?.statuses ?? ["Todo", "In Progress", "In Review", "Completed"];
  const idx = statuses.indexOf(item.status);
  const nextStatus = idx >= 0 && idx < statuses.length - 1 ? statuses[idx + 1] : null;

  return (
    <>
      {/* Header */}
      <header className="border-b border-border bg-card/60 backdrop-blur px-5 py-3 flex items-start gap-3 sticky top-0 z-10">
        <span
          className={cn(
            "inline-flex h-7 w-7 items-center justify-center rounded-md text-sm font-bold shrink-0 mt-0.5",
            meta.bg,
            meta.color,
          )}
          title={meta.label}
        >
          {meta.icon}
        </span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground font-mono">
            <span>{workspace?.name ?? item.workspaceCode}</span>
            <ChevronRight className="h-3 w-3" />
            <span>{meta.label}</span>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground">{item.id}</span>
          </div>
          <InlineTitle
            value={item.title}
            onChange={(v) => updateItem(item.id, { title: v })}
          />
          <div className="mt-2 flex items-center gap-1.5 flex-wrap">
            <Badge variant="secondary" className="bg-info/15 text-info border-0">
              {item.status}
            </Badge>
            <Badge variant="outline" className={cn(PRIORITY_META[item.priority].color)}>
              {PRIORITY_META[item.priority].label} priority
            </Badge>
            {sprint && (
              <Badge variant="outline">
                <Calendar className="h-3 w-3 mr-1" />
                {sprint.name}
              </Badge>
            )}
            <Badge variant="outline">{item.points} pts</Badge>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {nextStatus && (
            <Button
              size="sm"
              className="gap-1.5 bg-gradient-primary text-primary-foreground"
              onClick={() => {
                updateItem(item.id, { status: nextStatus });
                toast.success(`Moved to ${nextStatus}`);
              }}
            >
              {nextStatus === "In Progress" ? (
                <Play className="h-3.5 w-3.5" />
              ) : (
                <ArrowRight className="h-3.5 w-3.5" />
              )}
              {nextStatus === "In Progress"
                ? "Start progress"
                : nextStatus === "In Review"
                ? "Move to review"
                : nextStatus === "Completed"
                ? "Complete task"
                : `Move to ${nextStatus}`}
            </Button>
          )}
          {item.status === "Completed" && (
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5"
              onClick={() => {
                updateItem(item.id, { status: statuses[0] });
                toast.success("Reopened");
              }}
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reopen
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            className="gap-1.5"
            onClick={() => {
              navigator.clipboard?.writeText(`${item.id} · ${item.title}`);
              toast.success("Link copied");
            }}
          >
            <Share2 className="h-3.5 w-3.5" /> Share
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Body */}
      <div className="flex-1 grid grid-cols-[1fr_320px] min-h-0">
        {/* Center */}
        <div className="flex flex-col min-w-0 border-r border-border">
          <nav className="sticky top-0 z-[1] bg-card/80 backdrop-blur border-b border-border px-2 flex items-center gap-0 overflow-x-auto">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "inline-flex items-center gap-1.5 px-3 h-10 text-xs font-medium border-b-2 transition-colors whitespace-nowrap",
                    active
                      ? "border-primary text-foreground"
                      : "border-transparent text-muted-foreground hover:text-foreground",
                  )}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              );
            })}
          </nav>
          <div className="flex-1 overflow-y-auto p-6">
            {tab === "overview" && <OverviewTab item={item} onOpenOther={onOpenOther} />}
            {tab === "description" && <DescriptionTab item={item} />}
            {tab === "acceptance" && <AcceptanceTab item={item} />}
            {tab === "subtasks" && <SubtasksTab item={item} onOpenOther={onOpenOther} />}
            {tab === "dependencies" && <DependenciesTab item={item} onOpenOther={onOpenOther} />}
            {tab === "comments" && <CommentsTab item={item} />}
            {tab === "activity" && <ActivityTab item={item} />}
            {tab === "attachments" && <AttachmentsTab item={item} />}
            {tab === "time" && <TimeTrackingTab item={item} />}
            {tab === "development" && <DevelopmentTab item={item} />}
            {tab === "testing" && <TestingTab item={item} />}
          </div>
        </div>

        {/* Sidebar */}
        <aside className="overflow-y-auto bg-muted/20">
          <PropertiesSidebar item={item} />
        </aside>
      </div>
    </>
  );
}

/* ---------- Header inline title ---------- */
function InlineTitle({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  const commit = () => {
    setEditing(false);
    if (draft.trim() && draft !== value) onChange(draft.trim());
  };
  if (editing) {
    return (
      <Input
        autoFocus
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
          if (e.key === "Escape") {
            setDraft(value);
            setEditing(false);
          }
        }}
        className="text-xl font-semibold h-9 mt-1"
      />
    );
  }
  return (
    <h1
      className="text-xl font-semibold tracking-tight text-foreground mt-1 cursor-text hover:bg-muted/40 rounded px-1 -mx-1 inline-block"
      onClick={() => setEditing(true)}
    >
      {value}
    </h1>
  );
}

/* ---------- Sidebar ---------- */
function PropertiesSidebar({ item }: { item: BacklogItem }) {
  const { store, updateItem } = useWorkspaceStore();
  const workspace = store.workspaces.find((w) => w.code === item.workspaceCode);
  const sprints = store.sprints.filter((s) => s.workspaceCode === item.workspaceCode);
  const epics = store.items.filter(
    (i) => i.workspaceCode === item.workspaceCode && (i.type === "epic" || i.type === "feature") && i.id !== item.id,
  );
  const memberIds = Array.from(new Set([...(workspace?.ownerIds ?? []), ...(workspace?.memberIds ?? [])]));

  return (
    <div className="p-5 space-y-5 text-sm">
      <div>
        <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">
          Details
        </h3>
        <div className="space-y-3">
          <Row label="Assignee">
            <PersonSelect
              value={item.assigneeId}
              onChange={(v) => updateItem(item.id, { assigneeId: v })}
              memberIds={memberIds}
            />
          </Row>
          <Row label="Reporter">
            <PersonSelect
              value={item.reporterId}
              onChange={(v) => updateItem(item.id, { reporterId: v })}
              memberIds={memberIds}
            />
          </Row>
          <Row label="Status">
            <Select value={item.status} onValueChange={(v) => updateItem(item.id, { status: v })}>
              <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {(workspace?.statuses ?? []).map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Row>
          <Row label="Priority">
            <Select
              value={item.priority}
              onValueChange={(v) => updateItem(item.id, { priority: v as Priority })}
            >
              <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(PRIORITY_META) as Priority[]).map((p) => (
                  <SelectItem key={p} value={p}>{PRIORITY_META[p].label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Row>
          <Row label="Story points">
            <Input
              type="number"
              min={0}
              value={item.points}
              onChange={(e) => updateItem(item.id, { points: Number(e.target.value) || 0 })}
              className="h-7 text-xs"
            />
          </Row>
          <Row label="Sprint">
            <Select
              value={item.sprintId ?? "__b"}
              onValueChange={(v) => updateItem(item.id, { sprintId: v === "__b" ? undefined : v })}
            >
              <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__b">Backlog</SelectItem>
                {sprints.map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Row>
          <Row label="Epic / Parent">
            <Select
              value={item.parentId ?? "__n"}
              onValueChange={(v) => updateItem(item.id, { parentId: v === "__n" ? undefined : v })}
            >
              <SelectTrigger className="h-7 text-xs"><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__n">None</SelectItem>
                {epics.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    [{ISSUE_TYPE_META[e.type].label}] {e.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Row>
          <Row label="Team">
            <Input
              value={item.team ?? ""}
              onChange={(e) => updateItem(item.id, { team: e.target.value })}
              className="h-7 text-xs"
            />
          </Row>
          <Row label="Release">
            <Input
              value={item.releaseVersion ?? ""}
              onChange={(e) => updateItem(item.id, { releaseVersion: e.target.value })}
              className="h-7 text-xs"
            />
          </Row>
          <Row label="Start date">
            <Input
              type="date"
              value={item.startDate ?? ""}
              onChange={(e) => updateItem(item.id, { startDate: e.target.value || undefined })}
              className="h-7 text-xs"
            />
          </Row>
          <Row label="Due date">
            <Input
              type="date"
              value={item.dueDate ?? ""}
              onChange={(e) => updateItem(item.id, { dueDate: e.target.value || undefined })}
              className="h-7 text-xs"
            />
          </Row>
        </div>
      </div>

      <div className="text-[11px] text-muted-foreground border-t border-border pt-3">
        Created {item.activity?.[0]?.at ? new Date(item.activity[0].at).toLocaleDateString() : "—"}
        <br />
        Last updated {item.activity?.[item.activity.length - 1]?.at ? new Date(item.activity[item.activity.length - 1].at).toLocaleString() : "—"}
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[110px_1fr] items-center gap-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

function PersonSelect({
  value,
  onChange,
  memberIds,
}: {
  value?: string;
  onChange: (v: string | undefined) => void;
  memberIds: string[];
}) {
  return (
    <Select value={value ?? "__n"} onValueChange={(v) => onChange(v === "__n" ? undefined : v)}>
      <SelectTrigger className="h-7 text-xs">
        <SelectValue placeholder="Unassigned" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="__n">Unassigned</SelectItem>
        {(memberIds.length ? memberIds : DIRECTORY.map((d) => d.id)).map((id) => {
          const p = DIRECTORY.find((d) => d.id === id);
          return (
            <SelectItem key={id} value={id}>
              {p?.name ?? id}
            </SelectItem>
          );
        })}
      </SelectContent>
    </Select>
  );
}

/* ---------- OVERVIEW ---------- */
function OverviewTab({ item, onOpenOther }: { item: BacklogItem; onOpenOther: (id: string) => void }) {
  const { store } = useWorkspaceStore();
  const subtasks = store.items.filter((i) => i.parentId === item.id);
  const sprint = store.sprints.find((s) => s.id === item.sprintId);
  const assignee = DIRECTORY.find((d) => d.id === item.assigneeId);
  const loggedHours = (item.worklogs ?? []).reduce((a, b) => a + b.hours, 0);
  const est = item.estimateHours ?? 0;
  const acDone = (item.acceptanceCriteria ?? []).filter((a) => a.done).length;
  const acTotal = (item.acceptanceCriteria ?? []).length;
  const subDone = subtasks.filter((s) => s.status === "Completed").length;
  const completion =
    acTotal === 0 && subtasks.length === 0
      ? item.status === "Completed"
        ? 100
        : item.status === "In Review"
        ? 75
        : item.status === "In Progress"
        ? 40
        : 10
      : Math.round(
          ((acDone + subDone) / Math.max(1, acTotal + subtasks.length)) * 100,
        );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        <SummaryCard label="Status" value={item.status} />
        <SummaryCard label="Story points" value={String(item.points)} />
        <SummaryCard label="Sprint" value={sprint?.name ?? "Backlog"} />
        <SummaryCard
          label="Assignee"
          value={assignee?.name ?? "Unassigned"}
          icon={item.assigneeId ? <PersonAvatar userId={item.assigneeId} size="sm" /> : null}
        />
        <SummaryCard label="Due date" value={item.dueDate ?? "—"} />
        <SummaryCard label="Progress" value={`${completion}%`} />
        <SummaryCard label="Time logged" value={`${loggedHours}h / ${est}h`} />
        <SummaryCard label="Priority" value={PRIORITY_META[item.priority].label} />
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Progress</h3>
          <span className="text-xs text-muted-foreground">{completion}% complete</span>
        </div>
        <Progress value={completion} className="h-2" />
        <div className="grid grid-cols-3 gap-4 mt-4 text-xs">
          <Stat label="Acceptance criteria" value={`${acDone}/${acTotal}`} />
          <Stat label="Subtasks done" value={`${subDone}/${subtasks.length}`} />
          <Stat label="Story points" value={`${item.points} pts`} />
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <h3 className="text-sm font-semibold mb-2">Summary</h3>
        <p className="text-sm text-muted-foreground whitespace-pre-wrap">
          {item.description?.trim() || "No description provided yet. Use the Description tab to add context."}
        </p>
      </div>

      <div className="rounded-xl border border-warning/30 bg-warning/5 p-5">
        <div className="flex items-center gap-2 mb-2 text-warning">
          <AlertTriangle className="h-4 w-4" />
          <h3 className="text-sm font-semibold">Key risks</h3>
        </div>
        <ul className="space-y-1 text-sm text-muted-foreground list-disc pl-5">
          <li>Dependent on external API contract — schedule may slip if upstream changes.</li>
          <li>QA coverage limited until staging environment is refreshed.</li>
          {!item.dueDate && <li>No due date set — recommended for sprint commitment.</li>}
        </ul>
      </div>

      {subtasks.length > 0 && (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="px-5 py-3 border-b border-border text-sm font-semibold">Subtasks</div>
          <div className="divide-y divide-border">
            {subtasks.slice(0, 4).map((s) => (
              <button
                key={s.id}
                onClick={() => onOpenOther(s.id)}
                className="w-full flex items-center gap-3 px-5 py-2 hover:bg-muted/40 text-left"
              >
                <span className="font-mono text-[11px] text-muted-foreground w-20">{s.id}</span>
                <span className="text-sm flex-1 truncate">{s.title}</span>
                <Badge variant="outline" className="text-[10px]">{s.status}</Badge>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 flex items-center gap-2 text-sm font-semibold text-foreground truncate">
        {icon}
        <span className="truncate">{value}</span>
      </div>
    </div>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground uppercase tracking-wider">{label}</div>
      <div className="text-sm font-semibold mt-0.5">{value}</div>
    </div>
  );
}

/* ---------- DESCRIPTION ---------- */
function DescriptionTab({ item }: { item: BacklogItem }) {
  const { updateItem } = useWorkspaceStore();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(item.description ?? "");
  useEffect(() => setDraft(item.description ?? ""), [item.description]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">Description</h2>
        {!editing && (
          <Button size="sm" variant="ghost" onClick={() => setEditing(true)}>Edit</Button>
        )}
      </div>
      {editing ? (
        <div className="space-y-2">
          <div className="flex gap-1 border border-border rounded-md p-1 bg-card">
            {["B", "I", "{ }", "•", "—", "🔗"].map((t) => (
              <button key={t} className="px-2 h-7 text-xs rounded hover:bg-muted">{t}</button>
            ))}
          </div>
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={12}
            placeholder="Add context, links, design references…"
            className="font-mono text-sm"
          />
          <div className="flex gap-2 justify-end">
            <Button size="sm" variant="outline" onClick={() => { setEditing(false); setDraft(item.description ?? ""); }}>
              Cancel
            </Button>
            <Button
              size="sm"
              className="bg-gradient-primary text-primary-foreground"
              onClick={() => {
                updateItem(item.id, { description: draft });
                setEditing(false);
                toast.success("Description saved");
              }}
            >
              Save
            </Button>
          </div>
        </div>
      ) : (
        <div
          className="rounded-lg border border-border bg-card p-5 min-h-[200px] text-sm whitespace-pre-wrap text-foreground/90 cursor-text"
          onClick={() => setEditing(true)}
        >
          {item.description?.trim() || (
            <span className="text-muted-foreground">Click to add a description…</span>
          )}
        </div>
      )}
    </div>
  );
}

/* ---------- ACCEPTANCE ---------- */
function AcceptanceTab({ item }: { item: BacklogItem }) {
  const { addAcceptance, toggleAcceptance, removeAcceptance } = useWorkspaceStore();
  const [text, setText] = useState("");
  const list = item.acceptanceCriteria ?? [];
  const done = list.filter((a) => a.done).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">Acceptance criteria</h2>
        <span className="text-xs text-muted-foreground">{done}/{list.length} complete</span>
      </div>
      <Progress value={list.length ? (done / list.length) * 100 : 0} className="h-1.5" />
      <div className="rounded-lg border border-border bg-card divide-y divide-border">
        {list.length === 0 && (
          <div className="px-4 py-6 text-center text-sm text-muted-foreground">
            No acceptance criteria yet. Add the first one below.
          </div>
        )}
        {list.map((a) => (
          <div key={a.id} className="flex items-center gap-3 px-4 py-2.5 group">
            <button
              onClick={() => toggleAcceptance(item.id, a.id)}
              className={cn(
                "h-4 w-4 rounded border-2 flex items-center justify-center shrink-0",
                a.done ? "bg-success border-success text-white" : "border-border",
              )}
            >
              {a.done && <Check className="h-3 w-3" />}
            </button>
            <span className={cn("text-sm flex-1", a.done && "line-through text-muted-foreground")}>
              {a.text}
            </span>
            <Button
              size="icon"
              variant="ghost"
              className="h-6 w-6 opacity-0 group-hover:opacity-100"
              onClick={() => removeAcceptance(item.id, a.id)}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Add criterion and press Enter"
          onKeyDown={(e) => {
            if (e.key === "Enter" && text.trim()) {
              addAcceptance(item.id, text.trim());
              setText("");
            }
          }}
        />
        <Button
          onClick={() => {
            if (text.trim()) {
              addAcceptance(item.id, text.trim());
              setText("");
            }
          }}
        >
          <Plus className="h-4 w-4 mr-1" /> Add
        </Button>
      </div>
    </div>
  );
}

/* ---------- SUBTASKS ---------- */
function SubtasksTab({ item, onOpenOther }: { item: BacklogItem; onOpenOther: (id: string) => void }) {
  const { store, createItem, updateItem, deleteItem } = useWorkspaceStore();
  const workspace = store.workspaces.find((w) => w.code === item.workspaceCode);
  const subtasks = store.items.filter((i) => i.parentId === item.id);
  const [title, setTitle] = useState("");
  const done = subtasks.filter((s) => s.status === "Completed").length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">Subtasks</h2>
        <span className="text-xs text-muted-foreground">{done}/{subtasks.length} complete</span>
      </div>
      <Progress value={subtasks.length ? (done / subtasks.length) * 100 : 0} className="h-1.5" />

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <div className="grid grid-cols-[100px_1fr_120px_120px_100px_80px_100px_40px] text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2 border-b border-border bg-muted/30">
          <div>ID</div>
          <div>Title</div>
          <div>Assignee</div>
          <div>Status</div>
          <div>Priority</div>
          <div>Points</div>
          <div>Due</div>
          <div></div>
        </div>
        {subtasks.length === 0 ? (
          <div className="px-4 py-8 text-center text-sm text-muted-foreground">
            No subtasks yet. Break this work down below.
          </div>
        ) : (
          subtasks.map((s) => (
            <div
              key={s.id}
              className="grid grid-cols-[100px_1fr_120px_120px_100px_80px_100px_40px] items-center px-3 py-2 border-b border-border last:border-b-0 hover:bg-muted/30 text-sm"
            >
              <button onClick={() => onOpenOther(s.id)} className="font-mono text-[11px] text-primary text-left truncate">
                {s.id}
              </button>
              <button onClick={() => onOpenOther(s.id)} className="text-left truncate">
                {s.title}
              </button>
              <div>
                {s.assigneeId ? (
                  <div className="flex items-center gap-1.5">
                    <PersonAvatar userId={s.assigneeId} size="sm" />
                    <span className="text-xs truncate">
                      {DIRECTORY.find((d) => d.id === s.assigneeId)?.name.split(" ")[0]}
                    </span>
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground">—</span>
                )}
              </div>
              <Select value={s.status} onValueChange={(v) => updateItem(s.id, { status: v })}>
                <SelectTrigger className="h-6 text-[11px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(workspace?.statuses ?? []).map((st) => (
                    <SelectItem key={st} value={st}>{st}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <span className={cn("text-xs font-medium", PRIORITY_META[s.priority].color)}>
                {PRIORITY_META[s.priority].label}
              </span>
              <span className="text-xs">{s.points}</span>
              <span className="text-xs text-muted-foreground">{s.dueDate ?? "—"}</span>
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => deleteItem(s.id)}>
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          ))
        )}
      </div>

      <div className="flex gap-2">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="+ Add a subtask title and press Enter"
          onKeyDown={(e) => {
            if (e.key === "Enter" && title.trim()) {
              createItem({
                workspaceCode: item.workspaceCode,
                type: "task",
                title: title.trim(),
                priority: "medium",
                points: 1,
                parentId: item.id,
                sprintId: item.sprintId,
                status: workspace?.statuses[0] ?? "Todo",
              });
              setTitle("");
              toast.success("Subtask added");
            }
          }}
        />
      </div>
    </div>
  );
}

/* ---------- DEPENDENCIES ---------- */
function DependenciesTab({ item, onOpenOther }: { item: BacklogItem; onOpenOther: (id: string) => void }) {
  const { store, addLink, removeLink } = useWorkspaceStore();
  const candidates = store.items.filter((i) => i.workspaceCode === item.workspaceCode && i.id !== item.id);
  const [linkType, setLinkType] = useState<LinkType>("blocks");
  const [targetId, setTargetId] = useState<string | undefined>();

  const links = item.links ?? [];
  const grouped = (Object.keys(LINK_TYPE_META) as LinkType[]).map((t) => ({
    type: t,
    items: links.filter((l) => l.type === t),
  }));

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold mb-3">Add a link</h3>
        <div className="flex gap-2">
          <Select value={linkType} onValueChange={(v) => setLinkType(v as LinkType)}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              {(Object.keys(LINK_TYPE_META) as LinkType[]).map((t) => (
                <SelectItem key={t} value={t}>{LINK_TYPE_META[t].label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={targetId} onValueChange={setTargetId}>
            <SelectTrigger className="flex-1"><SelectValue placeholder="Select issue…" /></SelectTrigger>
            <SelectContent>
              {candidates.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.id} · {c.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            disabled={!targetId}
            onClick={() => {
              if (targetId) {
                addLink(item.id, linkType, targetId);
                setTargetId(undefined);
                toast.success("Link added");
              }
            }}
          >
            Link
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {grouped.map(({ type, items }) => (
          <div key={type} className="rounded-lg border border-border bg-card overflow-hidden">
            <div className="px-4 py-2 border-b border-border flex items-center gap-2">
              <LinkIcon className={cn("h-3.5 w-3.5", LINK_TYPE_META[type].color)} />
              <span className="text-sm font-semibold">{LINK_TYPE_META[type].label}</span>
              <Badge variant="outline" className="ml-auto">{items.length}</Badge>
            </div>
            {items.length === 0 ? (
              <div className="px-4 py-6 text-center text-xs text-muted-foreground">No linked issues</div>
            ) : (
              <div className="divide-y divide-border">
                {items.map((l) => {
                  const tgt = candidates.find((c) => c.id === l.targetId);
                  if (!tgt) return null;
                  return (
                    <div key={l.id} className="px-4 py-2 flex items-center gap-2 hover:bg-muted/30 group">
                      <span className={cn("inline-flex h-4 w-4 items-center justify-center rounded text-[10px]", ISSUE_TYPE_META[tgt.type].bg, ISSUE_TYPE_META[tgt.type].color)}>
                        {ISSUE_TYPE_META[tgt.type].icon}
                      </span>
                      <button onClick={() => onOpenOther(tgt.id)} className="font-mono text-[11px] text-primary">{tgt.id}</button>
                      <button onClick={() => onOpenOther(tgt.id)} className="text-sm flex-1 truncate text-left">{tgt.title}</button>
                      <Badge variant="outline" className="text-[10px]">{tgt.status}</Badge>
                      {tgt.assigneeId && <PersonAvatar userId={tgt.assigneeId} size="sm" />}
                      <Button size="icon" variant="ghost" className="h-6 w-6 opacity-0 group-hover:opacity-100" onClick={() => removeLink(item.id, l.id)}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>

      <DependencyGraph item={item} candidates={candidates} />
    </div>
  );
}

function DependencyGraph({ item, candidates }: { item: BacklogItem; candidates: BacklogItem[] }) {
  const links = item.links ?? [];
  if (links.length === 0) return null;
  const nodes = [{ id: item.id, label: item.id, x: 300, y: 100, primary: true }];
  links.forEach((l, idx) => {
    const t = candidates.find((c) => c.id === l.targetId);
    if (!t) return;
    const angle = (idx / Math.max(1, links.length)) * Math.PI * 2;
    nodes.push({
      id: t.id,
      label: t.id,
      x: 300 + Math.cos(angle) * 180,
      y: 100 + Math.sin(angle) * 70,
      primary: false,
    });
  });

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <h3 className="text-sm font-semibold mb-2">Dependency graph</h3>
      <svg viewBox="0 0 600 220" className="w-full h-[220px]">
        {nodes.slice(1).map((n) => (
          <line
            key={`l-${n.id}`}
            x1={nodes[0].x}
            y1={nodes[0].y}
            x2={n.x}
            y2={n.y}
            className="stroke-border"
            strokeWidth={1.5}
            strokeDasharray="4 3"
          />
        ))}
        {nodes.map((n) => (
          <g key={n.id} transform={`translate(${n.x}, ${n.y})`}>
            <rect
              x={-50}
              y={-16}
              width={100}
              height={32}
              rx={6}
              className={n.primary ? "fill-primary" : "fill-card stroke-border"}
              strokeWidth={1}
            />
            <text
              textAnchor="middle"
              dy={4}
              className={cn("text-[10px] font-mono", n.primary ? "fill-primary-foreground" : "fill-foreground")}
            >
              {n.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ---------- COMMENTS ---------- */
const EMOJIS = ["👍", "🎉", "🚀", "❤️", "👀", "🤔"];
function CommentsTab({ item }: { item: BacklogItem }) {
  const { addComment, toggleReaction } = useWorkspaceStore();
  const [body, setBody] = useState("");
  const [internal, setInternal] = useState(false);
  const comments = item.comments ?? [];

  return (
    <div className="space-y-4">
      <h2 className="text-sm font-semibold">Comments ({comments.length})</h2>
      <div className="space-y-4">
        {comments.map((c) => {
          const author = DIRECTORY.find((d) => d.id === c.authorId);
          return (
            <div key={c.id} className={cn("rounded-lg border p-4", c.internal ? "border-warning/40 bg-warning/5" : "border-border bg-card")}>
              <div className="flex items-center gap-2 mb-2">
                <PersonAvatar userId={c.authorId} size="sm" />
                <span className="text-sm font-semibold">{author?.name ?? c.authorId}</span>
                <span className="text-[11px] text-muted-foreground">{new Date(c.createdAt).toLocaleString()}</span>
                {c.internal && <Badge variant="outline" className="text-[10px] text-warning border-warning/40">Internal</Badge>}
              </div>
              <p className="text-sm text-foreground whitespace-pre-wrap">
                {c.body.split(/(@u\d+)/).map((part, i) =>
                  part.startsWith("@u") ? (
                    <span key={i} className="text-primary font-medium">
                      @{DIRECTORY.find((d) => d.id === part.slice(1))?.name.split(" ")[0] ?? part.slice(1)}
                    </span>
                  ) : (
                    <span key={i}>{part}</span>
                  ),
                )}
              </p>
              <div className="flex items-center gap-1.5 mt-2">
                {c.reactions.map((r) => (
                  <button
                    key={r.emoji}
                    onClick={() => toggleReaction(item.id, c.id, r.emoji, CURRENT_USER_ID)}
                    className={cn(
                      "inline-flex items-center gap-1 h-6 px-2 rounded-full border text-xs",
                      r.userIds.includes(CURRENT_USER_ID) ? "bg-primary/10 border-primary/40" : "border-border",
                    )}
                  >
                    <span>{r.emoji}</span>
                    <span className="text-[10px]">{r.userIds.length}</span>
                  </button>
                ))}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button size="icon" variant="ghost" className="h-6 w-6">
                      <Smile className="h-3.5 w-3.5" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-1" align="start">
                    <div className="flex gap-1">
                      {EMOJIS.map((e) => (
                        <button
                          key={e}
                          className="h-8 w-8 hover:bg-muted rounded text-base"
                          onClick={() => toggleReaction(item.id, c.id, e, CURRENT_USER_ID)}
                        >
                          {e}
                        </button>
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          );
        })}
      </div>

      <div className="sticky bottom-0 -mx-6 -mb-6 mt-4 px-6 py-4 bg-background/80 backdrop-blur border-t border-border">
        <div className="rounded-lg border border-border bg-card p-3">
          <Textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Write a comment… Use @ to mention teammates (try @u2, @u3)"
            rows={2}
            className="border-0 focus-visible:ring-0 resize-none p-0"
          />
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 text-xs text-muted-foreground cursor-pointer">
                <input type="checkbox" checked={internal} onChange={(e) => setInternal(e.target.checked)} />
                Internal note
              </label>
              <Button size="icon" variant="ghost" className="h-7 w-7"><Paperclip className="h-3.5 w-3.5" /></Button>
              <Button size="icon" variant="ghost" className="h-7 w-7"><Smile className="h-3.5 w-3.5" /></Button>
            </div>
            <Button
              size="sm"
              className="bg-gradient-primary text-primary-foreground"
              disabled={!body.trim()}
              onClick={() => {
                addComment(item.id, { authorId: CURRENT_USER_ID, body: body.trim(), internal });
                setBody("");
                setInternal(false);
                toast.success("Comment posted");
              }}
            >
              Comment
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- ACTIVITY ---------- */
function ActivityTab({ item }: { item: BacklogItem }) {
  const [filter, setFilter] = useState<"all" | "comment" | "history" | "worklog" | "automation">("all");
  const all = item.activity ?? [];
  const filtered = all.filter((a) => {
    if (filter === "all") return true;
    if (filter === "comment") return a.type === "comment";
    if (filter === "worklog") return a.type === "worklog";
    if (filter === "automation") return a.type === "automation";
    return a.type !== "comment" && a.type !== "worklog" && a.type !== "automation";
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <h2 className="text-sm font-semibold mr-2">Activity</h2>
        {[
          { v: "all", l: "All" },
          { v: "comment", l: "Comments" },
          { v: "history", l: "History" },
          { v: "worklog", l: "Worklogs" },
          { v: "automation", l: "Automation" },
        ].map((f) => (
          <button
            key={f.v}
            onClick={() => setFilter(f.v as "all")}
            className={cn(
              "h-7 px-3 rounded-full text-xs border",
              filter === f.v ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground",
            )}
          >
            {f.l}
          </button>
        ))}
      </div>
      <div className="relative pl-6">
        <div className="absolute left-[10px] top-2 bottom-2 w-px bg-border" />
        {filtered
          .slice()
          .reverse()
          .map((a) => {
            const actor = DIRECTORY.find((d) => d.id === a.actorId);
            return (
              <div key={a.id} className="relative mb-4">
                <div className="absolute -left-[18px] top-1">
                  <PersonAvatar userId={a.actorId} size="sm" />
                </div>
                <div className="text-sm">
                  <span className="font-semibold">{actor?.name ?? a.actorId}</span>
                  <span className="text-muted-foreground"> {a.text}</span>
                </div>
                <div className="text-[11px] text-muted-foreground">{new Date(a.at).toLocaleString()}</div>
              </div>
            );
          })}
        {filtered.length === 0 && (
          <div className="text-sm text-muted-foreground py-6 text-center">No activity for this filter.</div>
        )}
      </div>
    </div>
  );
}

/* ---------- ATTACHMENTS ---------- */
function AttachmentsTab({ item }: { item: BacklogItem }) {
  const { addAttachment, removeAttachment } = useWorkspaceStore();
  const fileRef = useRef<HTMLInputElement>(null);
  const atts = item.attachments ?? [];

  const onFiles = (files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach((f) => {
      const url = URL.createObjectURL(f);
      addAttachment(item.id, {
        name: f.name,
        mime: f.type || "application/octet-stream",
        size: f.size,
        url,
        uploadedBy: CURRENT_USER_ID,
      });
    });
    toast.success(`${files.length} file(s) attached`);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">Attachments ({atts.length})</h2>
        <Button size="sm" className="gap-1.5" onClick={() => fileRef.current?.click()}>
          <Upload className="h-3.5 w-3.5" /> Upload
        </Button>
        <input ref={fileRef} type="file" multiple hidden onChange={(e) => onFiles(e.target.files)} />
      </div>

      <div
        className="rounded-lg border-2 border-dashed border-border bg-card/50 p-8 text-center"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          onFiles(e.dataTransfer.files);
        }}
      >
        <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">Drag and drop files here, or click Upload</p>
      </div>

      {atts.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {atts.map((a) => {
            const uploader = DIRECTORY.find((d) => d.id === a.uploadedBy);
            const isImg = a.mime.startsWith("image/");
            return (
              <div key={a.id} className="rounded-lg border border-border bg-card overflow-hidden group">
                <div className="aspect-video bg-muted flex items-center justify-center">
                  {isImg ? (
                    <img src={a.url} alt={a.name} className="w-full h-full object-cover" />
                  ) : (
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  )}
                </div>
                <div className="p-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-medium truncate">{a.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {(a.size / 1024).toFixed(1)} KB · v{a.version}
                      </p>
                    </div>
                    <Button size="icon" variant="ghost" className="h-6 w-6 opacity-0 group-hover:opacity-100" onClick={() => removeAttachment(item.id, a.id)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="mt-1.5 flex items-center gap-1 text-[10px] text-muted-foreground">
                    <PersonAvatar userId={a.uploadedBy} size="sm" />
                    <span className="truncate">{uploader?.name.split(" ")[0]}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------- TIME TRACKING ---------- */
function TimeTrackingTab({ item }: { item: BacklogItem }) {
  const { updateItem, addWorklog } = useWorkspaceStore();
  const wlogs = item.worklogs ?? [];
  const logged = wlogs.reduce((a, b) => a + b.hours, 0);
  const est = item.estimateHours ?? 0;
  const remaining = item.remainingHours ?? Math.max(0, est - logged);
  const pct = est ? Math.min(100, (logged / est) * 100) : 0;

  const [hours, setHours] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [comment, setComment] = useState("");

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3">
        <SummaryCard label="Original estimate" value={`${est}h`} />
        <SummaryCard label="Time spent" value={`${logged}h`} />
        <SummaryCard label="Remaining" value={`${remaining}h`} />
      </div>
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-center justify-between text-xs mb-2">
          <span>Burn rate</span>
          <span className="text-muted-foreground">{pct.toFixed(0)}% of estimate</span>
        </div>
        <div className="h-3 w-full rounded-full bg-muted overflow-hidden">
          <div
            className={cn("h-full", pct > 100 ? "bg-destructive" : "bg-gradient-primary")}
            style={{ width: `${Math.min(100, pct)}%` }}
          />
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-4 space-y-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <TrendingUp className="h-4 w-4" /> Log work
        </h3>
        <div className="grid grid-cols-[100px_140px_1fr_100px] gap-2">
          <Input type="number" step="0.25" placeholder="Hours" value={hours} onChange={(e) => setHours(e.target.value)} />
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <Input placeholder="What did you work on?" value={comment} onChange={(e) => setComment(e.target.value)} />
          <Button
            disabled={!hours}
            onClick={() => {
              const h = Number(hours);
              if (!h) return;
              addWorklog(item.id, { userId: CURRENT_USER_ID, hours: h, date, comment });
              setHours("");
              setComment("");
              toast.success("Work logged");
            }}
          >
            Add
          </Button>
        </div>
        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Update estimate (h)"
            value={item.estimateHours ?? ""}
            onChange={(e) => updateItem(item.id, { estimateHours: Number(e.target.value) || 0 })}
            className="max-w-[200px]"
          />
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <div className="grid grid-cols-[110px_180px_80px_1fr] px-3 py-2 border-b border-border text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          <div>Date</div>
          <div>User</div>
          <div>Hours</div>
          <div>Comment</div>
        </div>
        {wlogs.length === 0 ? (
          <div className="px-4 py-6 text-sm text-muted-foreground text-center">No work logged yet.</div>
        ) : (
          wlogs.map((w) => (
            <div key={w.id} className="grid grid-cols-[110px_180px_80px_1fr] px-3 py-2 border-b border-border last:border-b-0 text-sm">
              <div>{w.date}</div>
              <div className="flex items-center gap-1.5">
                <PersonAvatar userId={w.userId} size="sm" />
                <span className="text-xs">{DIRECTORY.find((d) => d.id === w.userId)?.name}</span>
              </div>
              <div className="font-semibold">{w.hours}h</div>
              <div className="text-muted-foreground truncate">{w.comment ?? "—"}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ---------- DEVELOPMENT ---------- */
function DevelopmentTab({ item }: { item: BacklogItem }) {
  const branch = `feature/${item.id.toLowerCase()}-${item.title.toLowerCase().split(" ").slice(0, 3).join("-")}`;
  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
          <GitBranch className="h-4 w-4" /> Branches
        </h3>
        <div className="flex items-center justify-between px-3 py-2 rounded-md bg-muted/40">
          <code className="text-xs font-mono">{branch}</code>
          <Badge variant="outline" className="text-success border-success/40">ahead 4</Badge>
        </div>
      </div>
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
          <GitPullRequest className="h-4 w-4" /> Pull requests
        </h3>
        {[
          { id: 482, title: `${item.title} — initial implementation`, state: "Open", reviews: 1 },
          { id: 471, title: `Refactor types for ${item.id}`, state: "Merged", reviews: 2 },
        ].map((pr) => (
          <div key={pr.id} className="flex items-center justify-between py-2 border-b border-border last:border-b-0">
            <div>
              <p className="text-sm font-medium">#{pr.id} {pr.title}</p>
              <p className="text-[11px] text-muted-foreground">Reviews: {pr.reviews}</p>
            </div>
            <Badge variant={pr.state === "Merged" ? "secondary" : "outline"}>{pr.state}</Badge>
          </div>
        ))}
      </div>
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold mb-3">Recent commits</h3>
        {["8f3a2b — Wire props", "c91e44 — Add tests", "1a2bcd — Initial scaffold"].map((c) => (
          <div key={c} className="text-xs font-mono py-1.5 border-b border-border last:border-b-0">{c}</div>
        ))}
      </div>
    </div>
  );
}

/* ---------- TESTING ---------- */
function TestingTab({ item }: { item: BacklogItem }) {
  const tests = [
    { id: "TC-101", name: "Renders default state", status: "Pass" },
    { id: "TC-102", name: "Handles empty data", status: "Pass" },
    { id: "TC-103", name: "Validates required inputs", status: "Fail" },
    { id: "TC-104", name: "Accessible via keyboard", status: "Untested" },
  ];
  const pass = tests.filter((t) => t.status === "Pass").length;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <SummaryCard label="Total" value={String(tests.length)} />
        <SummaryCard label="Passing" value={`${pass}/${tests.length}`} />
        <SummaryCard label="Coverage" value="78%" />
      </div>
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        {tests.map((t) => (
          <div key={t.id} className="flex items-center px-4 py-2.5 border-b border-border last:border-b-0">
            <span className="font-mono text-[11px] text-muted-foreground w-20">{t.id}</span>
            <span className="text-sm flex-1">{t.name}</span>
            <Badge
              variant="outline"
              className={cn(
                t.status === "Pass" && "text-success border-success/40",
                t.status === "Fail" && "text-destructive border-destructive/40",
                t.status === "Untested" && "text-muted-foreground",
              )}
            >
              {t.status}
            </Badge>
          </div>
        ))}
      </div>
    </div>
  );
}
