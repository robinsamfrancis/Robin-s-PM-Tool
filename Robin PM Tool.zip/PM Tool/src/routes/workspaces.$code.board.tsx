import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/EmptyState";
import { PersonAvatar } from "@/components/PersonAvatar";
import { useTaskDetail } from "@/components/task-detail/TaskDetailProvider";
import { KanbanSquare } from "lucide-react";
import {
  ISSUE_TYPE_META,
  PRIORITY_META,
  useWorkspace,
  useWorkspaceStore,
  type BacklogItem,
} from "@/lib/workspace-store";
import { cn } from "@/lib/utils";
import { useState } from "react";

export const Route = createFileRoute("/workspaces/$code/board")({
  component: BoardPage,
});

function BoardPage() {
  const { code } = Route.useParams();
  const workspace = useWorkspace(code);
  const { store, updateItem } = useWorkspaceStore();
  const [dragId, setDragId] = useState<string | null>(null);

  if (!workspace) return null;

  const activeSprint = store.sprints.find(
    (s) => s.workspaceCode === code && s.state === "active",
  );
  const items = store.items.filter(
    (i) => i.workspaceCode === code && (activeSprint ? i.sprintId === activeSprint.id : false),
  );

  if (!activeSprint) {
    return (
      <div className="mx-auto w-full max-w-3xl p-8">
        <EmptyState
          icon={KanbanSquare}
          title="No active sprint"
          description="Start a sprint from the Backlog tab to see your team's board come to life."
          actionLabel="Go to backlog"
          onAction={() => (window.location.href = `/workspaces/${code}/backlog`)}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 lg:px-8 py-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold text-foreground">{activeSprint.name}</h2>
          <p className="text-xs text-muted-foreground">
            {activeSprint.startDate} → {activeSprint.endDate}
          </p>
        </div>
      </div>
      <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${workspace.statuses.length}, minmax(260px, 1fr))` }}>
        {workspace.statuses.map((status) => {
          const colItems = items.filter((i) => i.status === status);
          return (
            <div
              key={status}
              className="rounded-2xl border border-border bg-card/50 flex flex-col min-h-[400px]"
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (!dragId) return;
                updateItem(dragId, { status });
                toast.success(`Moved to ${status}`);
                setDragId(null);
              }}
            >
              <div className="flex items-center justify-between px-3 py-2.5 border-b border-border">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {status}
                  </span>
                  <Badge variant="outline" className="h-5 font-mono">
                    {colItems.length}
                  </Badge>
                </div>
              </div>
              <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                {colItems.length === 0 && (
                  <p className="text-[11px] text-muted-foreground text-center py-6">
                    Drop items here
                  </p>
                )}
                {colItems.map((i) => (
                  <BoardCard
                    key={i.id}
                    item={i}
                    isDragging={dragId === i.id}
                    onDragStart={() => setDragId(i.id)}
                    onDragEnd={() => setDragId(null)}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function BoardCard({
  item,
  isDragging,
  onDragStart,
  onDragEnd,
}: {
  item: BacklogItem;
  isDragging: boolean;
  onDragStart: () => void;
  onDragEnd: () => void;
}) {
  const meta = ISSUE_TYPE_META[item.type];
  const { openTask } = useTaskDetail();
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onClick={() => openTask(item.id)}
      className={cn(
        "rounded-lg border border-border bg-background p-3 shadow-sm cursor-pointer hover:shadow-md hover:border-primary/40 transition-all",
        isDragging && "opacity-50",
      )}
    >
      <p className="text-xs font-medium text-foreground line-clamp-2">{item.title}</p>
      <div className="mt-2 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span
            className={cn(
              "inline-flex h-4 w-4 items-center justify-center rounded text-[10px] font-bold",
              meta.bg,
              meta.color,
            )}
          >
            {meta.icon}
          </span>
          <span className="font-mono text-[10px] text-muted-foreground">{item.id}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={cn("text-[10px] font-semibold", PRIORITY_META[item.priority].color)}>
            {PRIORITY_META[item.priority].label}
          </span>
          <span className="inline-flex h-5 min-w-5 px-1 items-center justify-center rounded-full bg-muted text-[10px] font-semibold text-foreground">
            {item.points}
          </span>
          {item.assigneeId && <PersonAvatar userId={item.assigneeId} size="sm" />}
        </div>
      </div>
    </div>
  );
}
