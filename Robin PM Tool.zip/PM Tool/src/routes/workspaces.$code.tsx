import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  CalendarRange,
  Edit3,
  KanbanSquare,
  Layers,
  Map as MapIcon,
  Plus,
  UserPlus,
  Users2,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/EmptyState";
import { AvatarStack } from "@/components/PersonAvatar";
import { useWorkspace, useWorkspaceStore } from "@/lib/workspace-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/workspaces/$code")({
  component: WorkspaceLayout,
});

function WorkspaceLayout() {
  const { code } = Route.useParams();
  const workspace = useWorkspace(code);
  const { store } = useWorkspaceStore();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  if (!workspace) {
    return (
      <AppShell title="Workspace">
        <div className="mx-auto w-full max-w-3xl p-8">
          <EmptyState
            icon={Layers}
            title="Workspace not found"
            description={`We couldn't find a workspace with code "${code}". It may have been deleted.`}
            actionLabel="Create a workspace"
            onAction={() => (window.location.href = "/workspaces/new")}
          />
        </div>
      </AppShell>
    );
  }

  const items = store.items.filter((i) => i.workspaceCode === code);
  const sprints = store.sprints.filter((s) => s.workspaceCode === code);
  const activeSprint = sprints.find((s) => s.state === "active");
  const sprintItems = activeSprint ? items.filter((i) => i.sprintId === activeSprint.id) : [];
  const done = sprintItems.filter((i) => i.status === "Completed");
  const completion = sprintItems.length
    ? Math.round((done.length / sprintItems.length) * 100)
    : 0;

  const health =
    completion >= 70
      ? { label: "On track", tone: "success" as const }
      : completion >= 40
        ? { label: "At risk", tone: "warning" as const }
        : { label: "Off track", tone: "destructive" as const };

  const tabs = [
    { to: `/workspaces/${code}/backlog`, label: "Backlog & Sprint", icon: Layers },
    { to: `/workspaces/${code}/board`, label: "Kanban Board", icon: KanbanSquare },
    { to: `/workspaces/${code}/roadmap`, label: "Roadmap", icon: MapIcon },
    { to: `/workspaces/${code}/team`, label: "Team", icon: Users2 },
  ];

  return (
    <AppShell title={workspace.name}>
      {/* Header */}
      <div className="border-b border-border bg-card/40">
        <div className="mx-auto w-full max-w-7xl px-4 lg:px-8 pt-6 pb-4">
          <div className="flex items-start justify-between gap-6 flex-wrap">
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground font-bold text-sm shadow-glow">
                  {workspace.code.slice(0, 2)}
                </div>
                <div>
                  <h1 className="text-xl font-semibold tracking-tight text-foreground">
                    {workspace.name}
                  </h1>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-mono font-semibold">{workspace.code}</span>
                    <span>·</span>
                    <span className="capitalize">{workspace.type}</span>
                    {workspace.parentCode && (
                      <>
                        <span>·</span>
                        <span>Parent: {workspace.parentCode}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 pt-3">
                <Stat icon={Activity} label="Health">
                  <Badge
                    className={cn(
                      "h-5",
                      health.tone === "success" && "bg-success/15 text-success",
                      health.tone === "warning" && "bg-warning/20 text-warning",
                      health.tone === "destructive" && "bg-destructive/15 text-destructive",
                    )}
                    variant="secondary"
                  >
                    {health.label}
                  </Badge>
                </Stat>
                <Stat icon={Users2} label="Owners">
                  {workspace.ownerIds.length > 0 ? (
                    <AvatarStack userIds={workspace.ownerIds} />
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </Stat>
                <Stat icon={Users2} label="Members">
                  {workspace.memberIds.length > 0 ? (
                    <AvatarStack userIds={workspace.memberIds} />
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </Stat>
                <Stat icon={CalendarRange} label="Current sprint">
                  <span className="text-xs font-medium text-foreground">
                    {activeSprint ? activeSprint.name : "No active sprint"}
                  </span>
                </Stat>
                <Stat icon={Activity} label="Completion">
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 w-24 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-primary"
                        style={{ width: `${completion}%` }}
                      />
                    </div>
                    <span className="text-xs font-semibold text-foreground">{completion}%</span>
                  </div>
                </Stat>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" className="gap-1.5">
                <Edit3 className="h-3.5 w-3.5" /> Edit
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5">
                <UserPlus className="h-3.5 w-3.5" /> Add members
              </Button>
              <Button asChild variant="outline" size="sm" className="gap-1.5">
                <Link to="/workspaces/$code/backlog" params={{ code }}>
                  <Plus className="h-3.5 w-3.5" /> Create sprint
                </Link>
              </Button>
              <Button
                asChild
                size="sm"
                className="gap-1.5 bg-gradient-primary text-primary-foreground hover:opacity-95"
              >
                <Link to="/workspaces/$code/backlog" params={{ code }}>
                  <Plus className="h-3.5 w-3.5" /> Create Epic
                </Link>
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <div className="mt-6 flex items-center gap-1 border-b border-border -mb-px">
            {tabs.map((t) => {
              const active = pathname === t.to || pathname.startsWith(t.to + "/");
              return (
                <Link
                  key={t.to}
                  to={t.to}
                  className={cn(
                    "flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors",
                    active
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-foreground",
                  )}
                >
                  <t.icon className="h-3.5 w-3.5" />
                  {t.label}
                </Link>
              );
            })}
          </div>
        </div>
      </div>

      <Outlet />
    </AppShell>
  );
}

function Stat({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof Activity;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex h-7 w-7 items-center justify-center rounded-md bg-muted text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
      </div>
      <div className="space-y-0.5">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
          {label}
        </p>
        {children}
      </div>
    </div>
  );
}
