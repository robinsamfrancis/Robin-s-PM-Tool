import { createFileRoute } from "@tanstack/react-router";
import { Star, UserPlus, Users2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PersonAvatar } from "@/components/PersonAvatar";
import { EmptyState } from "@/components/EmptyState";
import { DIRECTORY, useWorkspace, useWorkspaceStore } from "@/lib/workspace-store";

export const Route = createFileRoute("/workspaces/$code/team")({
  component: TeamPage,
});

function TeamPage() {
  const { code } = Route.useParams();
  const workspace = useWorkspace(code);
  const { store } = useWorkspaceStore();
  if (!workspace) return null;

  const memberIds = Array.from(new Set([...workspace.ownerIds, ...workspace.memberIds]));

  if (memberIds.length === 0) {
    return (
      <div className="mx-auto w-full max-w-3xl p-8">
        <EmptyState
          icon={Users2}
          title="No team members yet"
          description="Add team members to assign work and track ownership across your sprints."
          actionLabel="Add members"
          onAction={() => {}}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 lg:px-8 py-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">
          {memberIds.length} team members
        </h2>
        <Button size="sm" variant="outline" className="gap-1.5">
          <UserPlus className="h-3.5 w-3.5" /> Add member
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {memberIds.map((id) => {
          const p = DIRECTORY.find((x) => x.id === id);
          if (!p) return null;
          const isOwner = workspace.ownerIds.includes(id);
          const assignedCount = store.items.filter(
            (i) => i.workspaceCode === code && i.assigneeId === id,
          ).length;
          const pts = store.items
            .filter((i) => i.workspaceCode === code && i.assigneeId === id)
            .reduce((a, b) => a + b.points, 0);
          return (
            <div
              key={id}
              className="rounded-2xl border border-border bg-card p-5 hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-3">
                <PersonAvatar userId={id} size="lg" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                    {isOwner && (
                      <Star className="h-3 w-3 fill-warning text-warning" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{p.designation}</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-center">
                <div className="rounded-lg bg-muted/50 p-2">
                  <p className="text-base font-semibold text-foreground">{assignedCount}</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                    Assigned
                  </p>
                </div>
                <div className="rounded-lg bg-muted/50 p-2">
                  <p className="text-base font-semibold text-foreground">{pts}</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                    Story pts
                  </p>
                </div>
              </div>
              <div className="mt-3">
                <Badge variant="secondary" className="text-[10px]">
                  {isOwner ? "Space owner" : "Member"}
                </Badge>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
