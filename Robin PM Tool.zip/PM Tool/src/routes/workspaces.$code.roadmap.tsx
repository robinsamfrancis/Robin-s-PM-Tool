import { createFileRoute } from "@tanstack/react-router";
import { Map as MapIcon } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { useTaskDetail } from "@/components/task-detail/TaskDetailProvider";
import { ISSUE_TYPE_META, useWorkspace, useWorkspaceStore } from "@/lib/workspace-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/workspaces/$code/roadmap")({
  component: RoadmapPage,
});

function RoadmapPage() {
  const { code } = Route.useParams();
  const workspace = useWorkspace(code);
  const { store } = useWorkspaceStore();
  const { openTask } = useTaskDetail();
  if (!workspace) return null;

  const epics = store.items.filter(
    (i) => i.workspaceCode === code && (i.type === "epic" || i.type === "feature"),
  );

  if (epics.length === 0) {
    return (
      <div className="mx-auto w-full max-w-3xl p-8">
        <EmptyState
          icon={MapIcon}
          title="No epics or features yet"
          description="Create epics or features to plot a roadmap. Add start and due dates so they appear on the timeline."
          actionLabel="Go to backlog"
          onAction={() => (window.location.href = `/workspaces/${code}/backlog`)}
        />
      </div>
    );
  }

  // simple timeline
  const dated = epics.filter((e) => e.startDate && e.dueDate);
  const undated = epics.filter((e) => !e.startDate || !e.dueDate);

  const allDates = dated.flatMap((e) => [new Date(e.startDate!), new Date(e.dueDate!)]);
  const min = allDates.length ? new Date(Math.min(...allDates.map((d) => d.getTime()))) : new Date();
  const max = allDates.length ? new Date(Math.max(...allDates.map((d) => d.getTime()))) : new Date();
  const span = Math.max(1, max.getTime() - min.getTime());

  const months: { label: string; pct: number }[] = [];
  if (allDates.length) {
    const cursor = new Date(min.getFullYear(), min.getMonth(), 1);
    while (cursor <= max) {
      months.push({
        label: cursor.toLocaleString("default", { month: "short", year: "2-digit" }),
        pct: ((cursor.getTime() - min.getTime()) / span) * 100,
      });
      cursor.setMonth(cursor.getMonth() + 1);
    }
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 lg:px-8 py-6 space-y-6">
      {dated.length > 0 && (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <div className="relative h-10 border-b border-border bg-muted/30">
            {months.map((m, i) => (
              <div
                key={i}
                className="absolute top-0 bottom-0 border-l border-border pl-2 pt-2 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold"
                style={{ left: `${m.pct}%` }}
              >
                {m.label}
              </div>
            ))}
          </div>
          <div className="divide-y divide-border">
            {dated.map((e) => {
              const start = new Date(e.startDate!);
              const end = new Date(e.dueDate!);
              const leftPct = ((start.getTime() - min.getTime()) / span) * 100;
              const widthPct = Math.max(2, ((end.getTime() - start.getTime()) / span) * 100);
              const meta = ISSUE_TYPE_META[e.type];
              return (
                <div key={e.id} className="grid grid-cols-[200px_1fr] items-center cursor-pointer hover:bg-muted/30" onClick={() => openTask(e.id)}>
                  <div className="px-3 py-3 border-r border-border">
                    <div className="flex items-center gap-1.5">
                      <span className={cn("inline-flex h-4 w-4 items-center justify-center rounded text-[10px] font-bold", meta.bg, meta.color)}>
                        {meta.icon}
                      </span>
                      <span className="text-xs font-medium text-foreground truncate">{e.title}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{e.id}</p>
                  </div>
                  <div className="relative h-10">
                    <div
                      className="absolute top-1/2 -translate-y-1/2 h-6 rounded-md bg-gradient-primary text-primary-foreground text-[10px] font-semibold flex items-center px-2 shadow-glow"
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                      title={`${e.startDate} → ${e.dueDate}`}
                    >
                      {e.title}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {undated.length > 0 && (
        <div className="rounded-2xl border border-dashed border-border bg-card/50 p-5">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
            Unscheduled
          </h3>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {undated.map((e) => {
              const meta = ISSUE_TYPE_META[e.type];
              return (
                <div key={e.id} className="rounded-lg border border-border bg-background p-3 cursor-pointer hover:border-primary/40" onClick={() => openTask(e.id)}>
                  <div className="flex items-center gap-1.5">
                    <span className={cn("inline-flex h-4 w-4 items-center justify-center rounded text-[10px] font-bold", meta.bg, meta.color)}>
                      {meta.icon}
                    </span>
                    <span className="text-xs font-medium text-foreground truncate">{e.title}</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">Add start & due dates to schedule</p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
