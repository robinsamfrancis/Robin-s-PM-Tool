import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/workspaces/$code/")({
  beforeLoad: ({ params }) => {
    throw redirect({ to: "/workspaces/$code/backlog", params: { code: params.code } });
  },
});
