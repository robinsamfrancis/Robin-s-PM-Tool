import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Designation =
  | "Frontend Developer"
  | "Backend Developer"
  | "QA Engineer"
  | "UI/UX Designer"
  | "Product Analyst"
  | "DevOps Engineer";

export const DESIGNATIONS: Designation[] = [
  "Frontend Developer",
  "Backend Developer",
  "QA Engineer",
  "UI/UX Designer",
  "Product Analyst",
  "DevOps Engineer",
];

export interface Person {
  id: string;
  name: string;
  designation: Designation;
}

export const DIRECTORY: Person[] = [
  { id: "u1", name: "Alex Morgan", designation: "Frontend Developer" },
  { id: "u2", name: "Priya Singh", designation: "Backend Developer" },
  { id: "u3", name: "Diego Hernandez", designation: "QA Engineer" },
  { id: "u4", name: "Sophia Chen", designation: "UI/UX Designer" },
  { id: "u5", name: "Liam O'Connor", designation: "Product Analyst" },
  { id: "u6", name: "Aisha Khan", designation: "DevOps Engineer" },
  { id: "u7", name: "Marco Rossi", designation: "Backend Developer" },
  { id: "u8", name: "Nadia Petrova", designation: "Frontend Developer" },
  { id: "u9", name: "Kenji Tanaka", designation: "DevOps Engineer" },
  { id: "u10", name: "Emma Wilson", designation: "QA Engineer" },
];

export type IssueType = "epic" | "feature" | "story" | "task";
export type Priority = "lowest" | "low" | "medium" | "high" | "highest";
export type LinkType = "blocks" | "blockedBy" | "relatesTo" | "duplicates";

export interface AcceptanceCriterion {
  id: string;
  text: string;
  done: boolean;
}
export interface IssueLink {
  id: string;
  type: LinkType;
  targetId: string;
}
export interface Reaction {
  emoji: string;
  userIds: string[];
}
export interface Comment {
  id: string;
  authorId: string;
  body: string;
  createdAt: string;
  reactions: Reaction[];
  internal: boolean;
  parentId?: string;
}
export type ActivityType =
  | "created"
  | "updated"
  | "status"
  | "sprint"
  | "assignee"
  | "comment"
  | "attachment"
  | "worklog"
  | "automation";
export interface Activity {
  id: string;
  type: ActivityType;
  actorId: string;
  at: string;
  text: string;
}
export interface Attachment {
  id: string;
  name: string;
  mime: string;
  size: number;
  url: string;
  uploadedBy: string;
  uploadedAt: string;
  version: number;
}
export interface Worklog {
  id: string;
  userId: string;
  date: string;
  hours: number;
  comment?: string;
}

export interface BacklogItem {
  id: string;
  workspaceCode: string;
  type: IssueType;
  title: string;
  description?: string;
  priority: Priority;
  points: number;
  assigneeId?: string;
  reporterId?: string;
  sprintId?: string;
  parentId?: string;
  epicId?: string;
  budgetHours?: number;
  estimateHours?: number;
  remainingHours?: number;
  startDate?: string;
  dueDate?: string;
  status: string;
  order: number;
  team?: string;
  releaseVersion?: string;
  acceptanceCriteria?: AcceptanceCriterion[];
  links?: IssueLink[];
  comments?: Comment[];
  activity?: Activity[];
  attachments?: Attachment[];
  worklogs?: Worklog[];
  seededAt?: string;
}

export type SprintState = "planned" | "active" | "completed";

export interface Sprint {
  id: string;
  workspaceCode: string;
  name: string;
  goal?: string;
  durationWeeks: number | "custom";
  startDate: string;
  endDate: string;
  state: SprintState;
  leaves: Record<string, string[]>;
  summary?: string;
}

export type ProjectType = "in-house" | "client";

export interface Workspace {
  code: string;
  name: string;
  type: ProjectType;
  ownerIds: string[];
  memberIds: string[];
  parentCode?: string;
  statuses: string[];
  startDate?: string;
  endDate?: string;
  createdAt: string;
}

interface Store {
  workspaces: Workspace[];
  items: BacklogItem[];
  sprints: Sprint[];
}

const STORAGE_KEY = "bpm-store-v1";

const initialStore = (): Store => {
  if (typeof window === "undefined") return { workspaces: [], items: [], sprints: [] };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return { workspaces: [], items: [], sprints: [] };
};

const rid = (p: string) => `${p}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
const now = () => new Date().toISOString();

interface Ctx {
  store: Store;
  createWorkspace: (w: Omit<Workspace, "createdAt">) => void;
  updateWorkspace: (code: string, patch: Partial<Workspace>) => void;
  createItem: (item: Omit<BacklogItem, "id" | "order">) => BacklogItem;
  updateItem: (id: string, patch: Partial<BacklogItem>, actorId?: string) => void;
  deleteItem: (id: string) => void;
  moveItem: (id: string, targetSprintId: string | undefined) => void;
  createSprint: (s: Omit<Sprint, "id" | "state" | "leaves">) => Sprint;
  updateSprint: (id: string, patch: Partial<Sprint>) => void;
  startSprint: (id: string) => void;
  completeSprint: (id: string) => void;
  deleteSprint: (id: string) => void;
  // task detail extras
  addComment: (itemId: string, c: Omit<Comment, "id" | "createdAt" | "reactions">) => void;
  toggleReaction: (itemId: string, commentId: string, emoji: string, userId: string) => void;
  addAcceptance: (itemId: string, text: string) => void;
  toggleAcceptance: (itemId: string, acId: string) => void;
  removeAcceptance: (itemId: string, acId: string) => void;
  addLink: (itemId: string, type: LinkType, targetId: string) => void;
  removeLink: (itemId: string, linkId: string) => void;
  addWorklog: (itemId: string, w: Omit<Worklog, "id">) => void;
  addAttachment: (itemId: string, a: Omit<Attachment, "id" | "uploadedAt" | "version">) => void;
  removeAttachment: (itemId: string, attId: string) => void;
  seedItemDetails: (itemId: string) => void;
}

const StoreContext = createContext<Ctx | null>(null);

function logActivityArr(prev: Activity[] | undefined, type: ActivityType, actorId: string, text: string): Activity[] {
  const next = [...(prev ?? []), { id: rid("ACT"), type, actorId, at: now(), text }];
  return next.slice(-200);
}

export function WorkspaceStoreProvider({ children }: { children: ReactNode }) {
  const [store, setStore] = useState<Store>(initialStore);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    } catch {
      // ignore
    }
  }, [store]);

  const value = useMemo<Ctx>(
    () => ({
      store,
      createWorkspace: (w) =>
        setStore((s) => ({
          ...s,
          workspaces: [...s.workspaces, { ...w, createdAt: new Date().toISOString() }],
        })),
      updateWorkspace: (code, patch) =>
        setStore((s) => ({
          ...s,
          workspaces: s.workspaces.map((w) => (w.code === code ? { ...w, ...patch } : w)),
        })),
      createItem: (item) => {
        const newItem: BacklogItem = {
          ...item,
          id: `${item.workspaceCode}-${Math.floor(Math.random() * 900 + 100)}`,
          order: Date.now(),
          activity: [
            { id: rid("ACT"), type: "created", actorId: item.assigneeId ?? "u1", at: now(), text: "created this item" },
          ],
        };
        setStore((s) => ({ ...s, items: [...s.items, newItem] }));
        return newItem;
      },
      updateItem: (id, patch, actorId = "u1") =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) => {
            if (i.id !== id) return i;
            const next: BacklogItem = { ...i, ...patch };
            let activity = i.activity;
            if (patch.status && patch.status !== i.status) {
              activity = logActivityArr(activity, "status", actorId, `changed status from ${i.status} to ${patch.status}`);
            }
            if ("assigneeId" in patch && patch.assigneeId !== i.assigneeId) {
              const name = DIRECTORY.find((d) => d.id === patch.assigneeId)?.name ?? "Unassigned";
              activity = logActivityArr(activity, "assignee", actorId, `assigned to ${name}`);
            }
            if ("sprintId" in patch && patch.sprintId !== i.sprintId) {
              activity = logActivityArr(activity, "sprint", actorId, patch.sprintId ? `moved to sprint` : `moved to backlog`);
            }
            next.activity = activity;
            return next;
          }),
        })),
      deleteItem: (id) => setStore((s) => ({ ...s, items: s.items.filter((i) => i.id !== id) })),
      moveItem: (id, targetSprintId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === id
              ? {
                  ...i,
                  sprintId: targetSprintId,
                  activity: logActivityArr(i.activity, "sprint", "u1", targetSprintId ? "moved to sprint" : "moved to backlog"),
                }
              : i,
          ),
        })),
      createSprint: (sp) => {
        const newSprint: Sprint = {
          ...sp,
          id: `SPR-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
          state: "planned",
          leaves: {},
        };
        setStore((s) => ({ ...s, sprints: [...s.sprints, newSprint] }));
        return newSprint;
      },
      updateSprint: (id, patch) =>
        setStore((s) => ({
          ...s,
          sprints: s.sprints.map((sp) => (sp.id === id ? { ...sp, ...patch } : sp)),
        })),
      startSprint: (id) =>
        setStore((s) => ({
          ...s,
          sprints: s.sprints.map((sp) => (sp.id === id ? { ...sp, state: "active" as SprintState } : sp)),
        })),
      completeSprint: (id) =>
        setStore((s) => {
          const sprintItems = s.items.filter((i) => i.sprintId === id);
          const done = sprintItems.filter((i) => i.status === "Completed");
          const points = sprintItems.reduce((a, b) => a + b.points, 0);
          const donePts = done.reduce((a, b) => a + b.points, 0);
          const summary = `Completed ${done.length} of ${sprintItems.length} items · ${donePts}/${points} story points delivered.`;
          return {
            ...s,
            sprints: s.sprints.map((sp) =>
              sp.id === id ? { ...sp, state: "completed" as SprintState, summary } : sp,
            ),
          };
        }),
      deleteSprint: (id) =>
        setStore((s) => ({
          ...s,
          sprints: s.sprints.filter((sp) => sp.id !== id),
          items: s.items.map((i) => (i.sprintId === id ? { ...i, sprintId: undefined } : i)),
        })),
      addComment: (itemId, c) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? {
                  ...i,
                  comments: [...(i.comments ?? []), { ...c, id: rid("CMT"), createdAt: now(), reactions: [] }],
                  activity: logActivityArr(i.activity, "comment", c.authorId, "added a comment"),
                }
              : i,
          ),
        })),
      toggleReaction: (itemId, commentId, emoji, userId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) => {
            if (i.id !== itemId) return i;
            return {
              ...i,
              comments: (i.comments ?? []).map((c) => {
                if (c.id !== commentId) return c;
                const existing = c.reactions.find((r) => r.emoji === emoji);
                let reactions: Reaction[];
                if (!existing) reactions = [...c.reactions, { emoji, userIds: [userId] }];
                else if (existing.userIds.includes(userId))
                  reactions = c.reactions
                    .map((r) => (r.emoji === emoji ? { ...r, userIds: r.userIds.filter((u) => u !== userId) } : r))
                    .filter((r) => r.userIds.length > 0);
                else
                  reactions = c.reactions.map((r) =>
                    r.emoji === emoji ? { ...r, userIds: [...r.userIds, userId] } : r,
                  );
                return { ...c, reactions };
              }),
            };
          }),
        })),
      addAcceptance: (itemId, text) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? {
                  ...i,
                  acceptanceCriteria: [...(i.acceptanceCriteria ?? []), { id: rid("AC"), text, done: false }],
                }
              : i,
          ),
        })),
      toggleAcceptance: (itemId, acId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? {
                  ...i,
                  acceptanceCriteria: (i.acceptanceCriteria ?? []).map((a) =>
                    a.id === acId ? { ...a, done: !a.done } : a,
                  ),
                }
              : i,
          ),
        })),
      removeAcceptance: (itemId, acId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? { ...i, acceptanceCriteria: (i.acceptanceCriteria ?? []).filter((a) => a.id !== acId) }
              : i,
          ),
        })),
      addLink: (itemId, type, targetId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? { ...i, links: [...(i.links ?? []), { id: rid("LNK"), type, targetId }] }
              : i,
          ),
        })),
      removeLink: (itemId, linkId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId ? { ...i, links: (i.links ?? []).filter((l) => l.id !== linkId) } : i,
          ),
        })),
      addWorklog: (itemId, w) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? {
                  ...i,
                  worklogs: [...(i.worklogs ?? []), { ...w, id: rid("WL") }],
                  remainingHours: Math.max(0, (i.remainingHours ?? i.estimateHours ?? 0) - w.hours),
                  activity: logActivityArr(i.activity, "worklog", w.userId, `logged ${w.hours}h`),
                }
              : i,
          ),
        })),
      addAttachment: (itemId, a) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? {
                  ...i,
                  attachments: [
                    ...(i.attachments ?? []),
                    { ...a, id: rid("ATT"), uploadedAt: now(), version: 1 },
                  ],
                  activity: logActivityArr(i.activity, "attachment", a.uploadedBy, `attached ${a.name}`),
                }
              : i,
          ),
        })),
      removeAttachment: (itemId, attId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) =>
            i.id === itemId
              ? { ...i, attachments: (i.attachments ?? []).filter((a) => a.id !== attId) }
              : i,
          ),
        })),
      seedItemDetails: (itemId) =>
        setStore((s) => ({
          ...s,
          items: s.items.map((i) => {
            if (i.id !== itemId || i.seededAt) return i;
            const pick = (n: number) => DIRECTORY.slice(0, n);
            const today = new Date();
            const iso = (offset: number) => {
              const d = new Date(today);
              d.setDate(d.getDate() + offset);
              return d.toISOString();
            };
            return {
              ...i,
              seededAt: now(),
              reporterId: i.reporterId ?? "u5",
              estimateHours: i.estimateHours ?? (i.points || 3) * 4,
              remainingHours: i.remainingHours ?? Math.max(0, (i.points || 3) * 4 - 6),
              team: i.team ?? "Platform Squad",
              releaseVersion: i.releaseVersion ?? "v1.4.0",
              acceptanceCriteria: i.acceptanceCriteria?.length
                ? i.acceptanceCriteria
                : [
                    { id: rid("AC"), text: "Component renders without console warnings", done: true },
                    { id: rid("AC"), text: "Keyboard navigation works end-to-end", done: false },
                    { id: rid("AC"), text: "Meets WCAG AA color contrast", done: false },
                  ],
              comments: i.comments?.length
                ? i.comments
                : [
                    {
                      id: rid("CMT"),
                      authorId: "u5",
                      body: "Initial scope looks good. Let's confirm the acceptance criteria with QA before grooming.",
                      createdAt: iso(-3),
                      reactions: [{ emoji: "👍", userIds: ["u1", "u2"] }],
                      internal: false,
                    },
                    {
                      id: rid("CMT"),
                      authorId: "u2",
                      body: "I'll start on the API contract. @u1 can you sync on the frontend types?",
                      createdAt: iso(-2),
                      reactions: [{ emoji: "🚀", userIds: ["u1"] }],
                      internal: false,
                    },
                    {
                      id: rid("CMT"),
                      authorId: "u3",
                      body: "QA note: edge case for empty states needs a screenshot in the spec.",
                      createdAt: iso(-1),
                      reactions: [],
                      internal: true,
                    },
                  ],
              attachments: i.attachments?.length
                ? i.attachments
                : [
                    {
                      id: rid("ATT"),
                      name: "design-spec.png",
                      mime: "image/png",
                      size: 482311,
                      url: `https://picsum.photos/seed/${i.id}/600/400`,
                      uploadedBy: "u4",
                      uploadedAt: iso(-4),
                      version: 1,
                    },
                    {
                      id: rid("ATT"),
                      name: "requirements.pdf",
                      mime: "application/pdf",
                      size: 128321,
                      url: "#",
                      uploadedBy: "u5",
                      uploadedAt: iso(-5),
                      version: 2,
                    },
                  ],
              worklogs: i.worklogs?.length
                ? i.worklogs
                : [
                    { id: rid("WL"), userId: "u1", date: iso(-2).slice(0, 10), hours: 3.5, comment: "Initial implementation" },
                    { id: rid("WL"), userId: "u2", date: iso(-1).slice(0, 10), hours: 2, comment: "API wiring" },
                  ],
              activity: i.activity?.length
                ? i.activity
                : [
                    { id: rid("ACT"), type: "created", actorId: "u5", at: iso(-7), text: "created this item" },
                    { id: rid("ACT"), type: "assignee", actorId: "u5", at: iso(-6), text: `assigned to ${pick(1)[0].name}` },
                    { id: rid("ACT"), type: "status", actorId: "u1", at: iso(-4), text: "changed status from Todo to In Progress" },
                    { id: rid("ACT"), type: "comment", actorId: "u5", at: iso(-3), text: "added a comment" },
                    { id: rid("ACT"), type: "attachment", actorId: "u4", at: iso(-4), text: "attached design-spec.png" },
                    { id: rid("ACT"), type: "worklog", actorId: "u1", at: iso(-2), text: "logged 3.5h" },
                  ],
            };
          }),
        })),
    }),
    [store],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useWorkspaceStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useWorkspaceStore must be used within WorkspaceStoreProvider");
  return ctx;
}

export function useWorkspace(code: string) {
  const { store } = useWorkspaceStore();
  return store.workspaces.find((w) => w.code === code);
}

export const ISSUE_TYPE_META: Record<
  IssueType,
  { label: string; color: string; bg: string; icon: string }
> = {
  epic: { label: "Epic", color: "text-accent-foreground", bg: "bg-accent", icon: "◆" },
  feature: { label: "Feature", color: "text-primary", bg: "bg-primary/15", icon: "★" },
  story: { label: "Story", color: "text-info", bg: "bg-info/15", icon: "▌" },
  task: { label: "Task", color: "text-success", bg: "bg-success/15", icon: "✓" },
};

export const PRIORITY_META: Record<Priority, { label: string; color: string }> = {
  lowest: { label: "Lowest", color: "text-muted-foreground" },
  low: { label: "Low", color: "text-info" },
  medium: { label: "Medium", color: "text-warning" },
  high: { label: "High", color: "text-destructive" },
  highest: { label: "Highest", color: "text-destructive" },
};

export const LINK_TYPE_META: Record<LinkType, { label: string; color: string }> = {
  blocks: { label: "Blocks", color: "text-destructive" },
  blockedBy: { label: "Blocked by", color: "text-warning" },
  relatesTo: { label: "Relates to", color: "text-info" },
  duplicates: { label: "Duplicates", color: "text-muted-foreground" },
};

export const DEFAULT_STATUSES = ["Todo", "In Progress", "In Review", "Completed"];

export function avatarColor(id: string) {
  const colors = [
    "oklch(0.7 0.15 30)",
    "oklch(0.7 0.15 90)",
    "oklch(0.7 0.15 150)",
    "oklch(0.7 0.15 210)",
    "oklch(0.7 0.15 270)",
    "oklch(0.7 0.15 330)",
  ];
  let h = 0;
  for (const c of id) h = (h * 31 + c.charCodeAt(0)) | 0;
  return colors[Math.abs(h) % colors.length];
}

export function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}
